window.highlightCode = () => {
    Prism.highlightAll();
};
